import { useEffect, useState } from "react";

function useClock() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  return time;
}

export default function Navbar({ onNavigate }) {
  const time = useClock();
  const stamp = time.toISOString().replace("T", " ").slice(0, 19) + "Z";

  const links = [
    ["BRIEFING", "about"],
    ["TIMELINE", "timeline"],
    ["ARCHIVE", "gallery"],
    ["INTEL", "facts"],
    ["FEEDBACK", "access"],
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-steel bg-void/85 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5 shrink-0">
          <span className="w-2.5 h-2.5 rounded-full bg-radar animate-blip-pulse" />
          <span className="font-display font-bold tracking-[0.2em] text-sm md:text-base text-ink-primary">
            AREA&nbsp;51
          </span>
          <span className="hidden sm:inline font-mono text-[10px] text-ink-muted tracking-widest">
            // GROOM LAKE ARCHIVE
          </span>
        </div>

        <nav className="hidden md:flex items-center gap-6 font-mono text-xs tracking-widest text-ink-muted">
          {links.map(([label, id]) => (
            <button
              key={id}
              onClick={() => onNavigate(id)}
              className="hover:text-cyan-bright transition-colors"
            >
              {label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <span className="hidden lg:block font-mono text-[10px] text-ink-muted">{stamp}</span>
          <button
            onClick={() => onNavigate("access")}
            className="font-mono text-[11px] tracking-widest uppercase border border-cyan-bright/50 rounded-sm px-3 py-1.5 text-cyan-bright hover:bg-cyan-bright/10 transition-colors"
          >
            Leave Feedback
          </button>
        </div>
      </div>
    </header>
  );
}
