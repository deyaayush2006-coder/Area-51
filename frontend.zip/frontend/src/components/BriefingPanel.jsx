export default function BriefingPanel({ eyebrow, title, children, className = "", tag }) {
  return (
    <div className={`hud-panel hud-corners rounded-sm p-6 md:p-8 ${className}`}>
      <div className="flex items-start justify-between gap-4 mb-4">
        <div>
          {eyebrow && <p className="eyebrow mb-2">{eyebrow}</p>}
          {title && (
            <h3 className="font-display text-xl md:text-2xl font-bold uppercase tracking-wide text-ink-primary">
              {title}
            </h3>
          )}
        </div>
        {tag && (
          <span className="shrink-0 font-mono text-[10px] tracking-widest uppercase text-radar border border-radar/40 rounded-full px-2.5 py-1 bg-radar/10">
            {tag}
          </span>
        )}
      </div>
      {children}
    </div>
  );
}
