import Navbar from "./components/Navbar.jsx";
import RadarHero from "./components/RadarHero.jsx";
import About from "./components/About.jsx";
import Timeline from "./components/Timeline.jsx";
import Gallery from "./components/Gallery.jsx";
import Facts from "./components/Facts.jsx";
import FeedbackConsole from "./components/FeedbackConsole.jsx";
import Footer from "./components/Footer.jsx";
import ScanlineOverlay from "./components/ScanlineOverlay.jsx";

export default function App() {
  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <ScanlineOverlay />
      <Navbar onNavigate={scrollTo} />
      <main className="flex-1">
        <RadarHero onNavigate={scrollTo} />
        <About />
        <Timeline />
        <Gallery />
        <Facts />
        <FeedbackConsole />
      </main>
      <Footer />
    </div>
  );
}
